# Lock Screen iOS 27 (Android)

Écran de verrouillage façon iOS 27 : horloge Liquid Glass étirable, fonds d'écran et photos avec effet de profondeur
(détourage du sujet sur l'appareil), widgets, vraies notifications, lampe torche, appareil photo.

## Fabriquer l'APK (au choix)

### A. Avec Android Studio (le plus simple)
1. Dézippez, puis `File > Open` et choisissez le dossier `LockScreenIOS27`.
2. Laissez Android Studio synchroniser (il télécharge Gradle 8.7 et le SDK 34 si besoin).
3. Menu `Build > Build Bundle(s) / APK(s) > Build APK(s)`.
4. L'APK est dans `app/build/outputs/apk/debug/app-debug.apk` (déjà signé en mode debug : installable tel quel).

### B. Sans Android Studio (GitHub)
1. Créez un dépôt GitHub et poussez-y le contenu de ce dossier.
2. Onglet `Actions` > `Build APK` > `Run workflow`.
3. Téléchargez l'artefact `lockscreen-ios27-apk` (contient `app-debug.apk`).

## Installer
Copiez `app-debug.apk` sur le téléphone, ouvrez-le et autorisez « installer des applis inconnues » pour le navigateur ou le gestionnaire de fichiers.

## Au premier lancement
L'appli ouvre un écran de configuration et demande :
- Photos (fonds d'écran) et Notifications ;
- Accès aux notifications (pour afficher vos vraies notifications) ;
- Affichage par-dessus les autres applis (pour s'ouvrir dès que l'écran s'allume) ;
- Arrière-plan sans restriction de batterie.

Touchez ensuite « Activer l'écran de verrouillage ». Un service discret reste actif et ouvre l'appli à chaque allumage de l'écran
(et après un redémarrage du téléphone).

### Si « Accès aux notifications » est grisé (Android 13 et plus)
Pour une appli installée hors Play Store : Réglages > Applis > Lock Screen iOS 27 > menu ⋮ > « Autoriser les paramètres restreints », puis recommencez.

### Code de verrouillage (clavier iOS 27)
Appui long sur l'écran > « Personnaliser » > « Réglages » > « Définir un code » (4 ou 6 chiffres, au choix avant de saisir).
Ensuite, un balayage vers le haut ouvre le clavier ; après 5 erreurs, l'accès est bloqué 30 s (puis plus longtemps).
« Changer le code » et « Supprimer le code » demandent d'abord le code actuel.
Ce code s'ajoute à celui d'Android : gardez aussi un verrouillage système (code ou empreinte) pour une vraie protection.

### Démarrage instantané
Dès que l'écran s'éteint, l'appli se place au premier plan (au-dessus du verrouillage Android) : au prochain allumage, elle est déjà là, sans afficher le fond d'écran par défaut.
Une fois déverrouillé, elle se met en arrière-plan sans se fermer et garde fond d'écran, photos et réglages.

### Style de l'horloge
Appui long > « Personnaliser » > touchez l'horloge (ou Réglages > « Style de l'horloge ») :
- **Verre** (Liquid Glass), **Plein** (couleur unie) ou **Contour** ;
- 11 couleurs + un curseur arc-en-ciel pour n'importe quelle teinte ;
- police (Standard, Condensé, Serif, Mono) et épaisseur.
« Effets Liquid Glass » (Réglages) passe aussi les notifications, widgets, boutons et le clavier en version simple, sans effet de verre.
Tout est mémorisé.

### Notifications
Touchez une notification pour l'ouvrir (après déverrouillage), balayez-la vers la gauche pour l'effacer.

### Widgets personnalisables
Réglages > « Widgets… » (ou touchez la zone des widgets en mode Personnaliser) : 4 emplacements, plusieurs fois le même widget possible.
- **Météo / Météo détaillée / Pluie / Lever-coucher du soleil** : au choix n'importe quelle ville (recherche en ligne, données Open-Meteo), °C ou °F ;
- **Heure d'une ville** : un fuseau horaire par widget (Tokyo, Londres, Dakar...) ;
- **Compte à rebours** (nom + date), **Événement** (titre, heure, lieu), **Note** libre, **Batterie**.
Touchez ⚙ pour régler un widget, − pour le retirer.

### Verrouillage strict (Accueil / Récents / Retour)
Android ne permet pas à une appli de désactiver ses boutons. Quand le téléphone est verrouillé, si on appuie sur Accueil ou Récents, l'écran de verrouillage revient donc aussitôt au premier plan, et Retour est ignoré.
Pour ne jamais enfermer l'utilisateur : après 4 tentatives en 10 secondes, on peut sortir. Code de l'appli oublié : Réglages Android > Applis > Lock Screen iOS 27 > Stockage > Effacer les données.
Cela vaut dès que l'écran de verrouillage de l'appli est affiché (même sans verrouillage Android sur le téléphone) et jusqu'au balayage vers le haut (+ code). Réglages > Sécurité > « Verrouillage strict » pour le couper. L'appli exige l'autorisation « Affichage par-dessus les autres applis » pour revenir au premier plan.

### Animations au gyroscope
Réglages > « Animations au gyroscope » (interrupteur) et « Intensité du mouvement ».
« Mode économique » retire le flou en temps réel des cartes et boutons : il s'active tout seul si l'appareil a du mal à suivre.

### Écran d'accueil (launcher)
L'appli peut aussi être votre écran d'accueil. Réglages > Écran > « Écran d'accueil » > « Définir comme accueil par défaut » (ou Réglages Android > Applis > Applis par défaut > Accueil), puis « Accueil iOS 27 ».
- **Fond** indépendant de l'écran de verrouillage : photo, vidéo, assombrir ; **neige / guirlande** et **musique** (réglages communs, interrupteurs séparés pour l'accueil) ;
- **Applis** : vraies applis du téléphone, icônes dans votre forme (carré, arrondi, iOS, rond ou arrondi libre), tuiles en verre, taille, opacité, noms ;
- **Disposition** : grille de 3 à 6 colonnes et 3 à 8 lignes, mode Pages ou Tiroir (balayage vers le haut), dock de 3 à 6 icônes, barre de recherche, date/heure (même style que l'écran de verrouillage), widgets ;
- **Appui long sur une icône** : déplacer (toucher une autre icône pour échanger), dock, renommer, masquer, infos, désinstaller.
Le déverrouillage de l'écran de verrouillage ramène à cet accueil.

### Vidéo en fond
Réglages > Écran > « Importer une vidéo » : la vidéo joue en boucle, plein écran, sous l'horloge et les widgets. Son coupé par défaut (Réglages > « Son et musique » pour l'activer). Pas d'effet de profondeur sur les vidéos. « Assombrir le fond » (Réglages > Effets) aide à lire l'heure sur une vidéo claire.

### Effets de Noël
Réglages > Écran > « Effets de Noël » : neige entièrement réglable (quantité, tailles min/max, vitesse, vent, rafales, balancement, opacité, forme, couleur ou multicolore, profondeur, flocons flous, rotation, lueur, vent selon le gyroscope, neige au sol, devant/derrière l'horloge, bouton Tempête, préréglages) et guirlande lumineuse (palette, clignotement, taille, courbure).

### Son
Réglages > Écran > « Son et musique » : sons d'interface (clavier, déverrouillage), musique de fond (carillon « Jingle Bells », vent d'hiver ou votre propre fichier audio, qui boucle tant que l'écran est affiché) et son de la vidéo.

### Quitter l'appli
- Fermer l'appli depuis les applis récentes arrête aussi le verrouillage (rouvrez l'appli pour le relancer).
- Réglages > « Rester actif en arrière-plan » : garde le service actif (et relancé au démarrage du téléphone) même si l'appli est fermée.
- Réglages > « Quitter l'application » ou le bouton « Arrêter » de la notification : arrêt immédiat.

### Remarques
- Le verrouillage réel (code, empreinte) reste géré par Android : l'appli s'affiche par-dessus, et un balayage vers le haut demande votre code / empreinte, puis se ferme.
- Sur certains téléphones (Xiaomi, Oppo, Samsung...), il faut aussi autoriser « démarrage automatique » et désactiver l'économie de batterie pour l'appli.
- Le détourage des photos utilise le modèle ML Kit des services Google Play (téléchargé automatiquement au premier usage, internet nécessaire une fois).
- Pour modifier l'interface : `app/src/main/assets/index.html`.
