# Lock Screen iOS 27 (Android)

Écran de verrouillage façon iOS 27 : horloge Liquid Glass étirable, fonds d'écran et photos avec effet de profondeur
(détourage du sujet sur l'appareil), widgets, vraies notifications, lampe torche, appareil photo.

## Fabriquer l'APK (au choix)

### A. Avec Android Studio (le plus simple)
1. Dézippez, puis `File > Open` et choisissez le dossier `LockScreenIOS27`.
2. Laissez Android Studio synchroniser (il télécharge Gradle 8.7 et le SDK 34 si besoin).
3. Menu `Build > Build Bundle(s) / APK(s) > Build APK(s)`.
4. L'APK est dans `app/build/outputs/apk/debug/app-debug.apk` (déjà signé en mode debug : installable tel quel).

### B. Sans Android Studio (GitHub)
1. Créez un dépôt GitHub et poussez-y le contenu de ce dossier.
2. Onglet `Actions` > `Build APK` > `Run workflow`.
3. Téléchargez l'artefact `lockscreen-ios27-apk` (contient `app-debug.apk`).

## Installer
Copiez `app-debug.apk` sur le téléphone, ouvrez-le et autorisez « installer des applis inconnues » pour le navigateur ou le gestionnaire de fichiers.

## Au premier lancement
L'appli ouvre un écran de configuration et demande :
- Photos (fonds d'écran) et Notifications ;
- Accès aux notifications (pour afficher vos vraies notifications) ;
- Affichage par-dessus les autres applis (pour s'ouvrir dès que l'écran s'allume) ;
- Arrière-plan sans restriction de batterie.

Touchez ensuite « Activer l'écran de verrouillage ». Un service discret reste actif et ouvre l'appli à chaque allumage de l'écran
(et après un redémarrage du téléphone).

### Si « Accès aux notifications » est grisé (Android 13 et plus)
Pour une appli installée hors Play Store : Réglages > Applis > Lock Screen iOS 27 > menu ⋮ > « Autoriser les paramètres restreints », puis recommencez.

### Code de verrouillage (clavier iOS 27)
Appui long sur l'écran > « Personnaliser » > « Réglages » > « Définir un code » (4 ou 6 chiffres, au choix avant de saisir).
Ensuite, un balayage vers le haut ouvre le clavier ; après 5 erreurs, l'accès est bloqué 30 s (puis plus longtemps).
« Changer le code » et « Supprimer le code » demandent d'abord le code actuel.
Ce code s'ajoute à celui d'Android : gardez aussi un verrouillage système (code ou empreinte) pour une vraie protection.

### Remarques
- Le verrouillage réel (code, empreinte) reste géré par Android : l'appli s'affiche par-dessus, et un balayage vers le haut demande votre code / empreinte, puis se ferme.
- Sur certains téléphones (Xiaomi, Oppo, Samsung...), il faut aussi autoriser « démarrage automatique » et désactiver l'économie de batterie pour l'appli.
- Le détourage des photos utilise le modèle ML Kit des services Google Play (téléchargé automatiquement au premier usage, internet nécessaire une fois).
- Pour modifier l'interface : `app/src/main/assets/index.html`.
