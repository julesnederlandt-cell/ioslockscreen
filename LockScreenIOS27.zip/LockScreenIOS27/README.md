# Lock Screen iOS 27 (Android)

Écran de verrouillage façon iOS 27 : horloge Liquid Glass étirable, fonds d'écran et photos avec effet de profondeur
(détourage du sujet sur l'appareil), widgets, vraies notifications, lampe torche, appareil photo.

## Fabriquer l'APK (au choix)

### A. Avec Android Studio (le plus simple)
1. Dézippez, puis `File > Open` et choisissez le dossier `LockScreenIOS27`.
2. Laissez Android Studio synchroniser (il télécharge Gradle 8.7 et le SDK 34 si besoin).
3. Menu `Build > Build Bundle(s) / APK(s) > Build APK(s)`.
4. L'APK est dans `app/build/outputs/apk/debug/app-debug.apk` (déjà signé en mode debug : installable tel quel).

### B. Sans Android Studio (GitHub)
1. Créez un dépôt GitHub et poussez-y le contenu de ce dossier.
2. Onglet `Actions` > `Build APK` > `Run workflow`.
3. Téléchargez l'artefact `lockscreen-ios27-apk` (contient `app-debug.apk`).

## Installer
Copiez `app-debug.apk` sur le téléphone, ouvrez-le et autorisez « installer des applis inconnues » pour le navigateur ou le gestionnaire de fichiers.

## Au premier lancement
L'appli ouvre un écran de configuration et demande :
- Photos (fonds d'écran) et Notifications ;
- Accès aux notifications (pour afficher vos vraies notifications) ;
- Affichage par-dessus les autres applis (pour s'ouvrir dès que l'écran s'allume) ;
- Arrière-plan sans restriction de batterie.

Touchez ensuite « Activer l'écran de verrouillage ». Un service discret reste actif et ouvre l'appli à chaque allumage de l'écran
(et après un redémarrage du téléphone).

### Si « Accès aux notifications » est grisé (Android 13 et plus)
Pour une appli installée hors Play Store : Réglages > Applis > Lock Screen iOS 27 > menu ⋮ > « Autoriser les paramètres restreints », puis recommencez.

### Code de verrouillage (clavier iOS 27)
Appui long sur l'écran > « Personnaliser » > « Réglages » > « Définir un code » (4 ou 6 chiffres, au choix avant de saisir).
Ensuite, un balayage vers le haut ouvre le clavier ; après 5 erreurs, l'accès est bloqué 30 s (puis plus longtemps).
« Changer le code » et « Supprimer le code » demandent d'abord le code actuel.
Ce code s'ajoute à celui d'Android : gardez aussi un verrouillage système (code ou empreinte) pour une vraie protection.

### Démarrage instantané
Dès que l'écran s'éteint, l'appli se place au premier plan (au-dessus du verrouillage Android) : au prochain allumage, elle est déjà là, sans afficher le fond d'écran par défaut.
Une fois déverrouillé, elle se met en arrière-plan sans se fermer et garde fond d'écran, photos et réglages.

### Style de l'horloge
Appui long > « Personnaliser » > touchez l'horloge (ou Réglages > « Style de l'horloge ») :
- **Verre** (Liquid Glass), **Plein** (couleur unie) ou **Contour** ;
- 11 couleurs + un curseur arc-en-ciel pour n'importe quelle teinte ;
- police (Standard, Condensé, Serif, Mono) et épaisseur.
« Effets Liquid Glass » (Réglages) passe aussi les notifications, widgets, boutons et le clavier en version simple, sans effet de verre.
Tout est mémorisé.

### Notifications
Touchez une notification pour l'ouvrir (après déverrouillage), balayez-la vers la gauche pour l'effacer.

### Widgets personnalisables
Réglages > « Widgets… » (ou touchez la zone des widgets en mode Personnaliser) : 4 emplacements, plusieurs fois le même widget possible.
- **Météo / Météo détaillée / Pluie / Lever-coucher du soleil** : au choix n'importe quelle ville (recherche en ligne, données Open-Meteo), °C ou °F ;
- **Heure d'une ville** : un fuseau horaire par widget (Tokyo, Londres, Dakar...) ;
- **Compte à rebours** (nom + date), **Événement** (titre, heure, lieu), **Note** libre, **Batterie**.
Touchez ⚙ pour régler un widget, − pour le retirer.

### Verrouillage strict (Accueil / Récents / Retour)
Android ne permet pas à une appli de désactiver ses boutons. Quand le téléphone est verrouillé, si on appuie sur Accueil ou Récents, l'écran de verrouillage revient donc aussitôt au premier plan, et Retour est ignoré.
Pour ne jamais enfermer l'utilisateur : après 4 tentatives en 10 secondes, on peut sortir. Code de l'appli oublié : Réglages Android > Applis > Lock Screen iOS 27 > Stockage > Effacer les données.
Cela vaut dès que l'écran de verrouillage de l'appli est affiché (même sans verrouillage Android sur le téléphone) et jusqu'au balayage vers le haut (+ code). Réglages > Sécurité > « Verrouillage strict » pour le couper. L'appli exige l'autorisation « Affichage par-dessus les autres applis » pour revenir au premier plan.

### Animations au gyroscope
Réglages > « Animations au gyroscope » (interrupteur) et « Intensité du mouvement ».
« Mode économique » retire le flou en temps réel des cartes et boutons : il s'active tout seul si l'appareil a du mal à suivre.

### Écran d'accueil (launcher)
L'appli peut aussi être votre écran d'accueil. Réglages > Écran > « Écran d'accueil » > « Définir comme accueil par défaut » (ou Réglages Android > Applis > Applis par défaut > Accueil), puis « Accueil iOS 27 ».
- **Modifier l'écran** : maintenez le doigt sur l'écran (ou sur une icône). Les icônes se mettent à bouger, et une barre apparaît en haut : Widgets, + Page, 🗑 Page, **Réglages** (le bouton Réglages n'est visible qu'à ce moment-là), OK.
- **Déplacer** : faites glisser une icône (vers une autre place, une autre page — maintenez-la au bord de l'écran pour changer de page — ou dans le dock).
- **Supprimer** : le « − » sur une icône la retire de l'accueil (elle reste dans le tiroir et la bibliothèque) ; « − » sur un widget ou sur l'heure les retire. Toucher une icône en mode édition ouvre son menu (dock, renommer, masquer, infos, désinstaller). Les widgets de l'accueil sont indépendants de ceux de l'écran de verrouillage.
- **Pages** : « + Page » en ajoute une, « 🗑 Page » (à toucher deux fois) supprime la page affichée ; ses applis restent dans le tiroir.
- **Bibliothèque d'applis** : dernière page, applis classées par catégories (comme sur iOS) ; toucher une catégorie ouvre sa liste.
- **Icônes façon iOS 26** (Réglages de l'accueil > « Personnaliser les icônes ») : **Défaut**, **Sombre**, **Transparent** (verre clair) ou **Teinté**, avec un curseur de teinte, un curseur de saturation (blanc vers la couleur) et Clair / Sombre / Auto ; forme, arrondi, taille, opacité, noms. Les icônes Transparent/Teintées utilisent le glyphe de l'icône (couche monochrome Android 13+ si l'appli en fournit une).
- **Heure** : taille, position verticale, alignement, format 12/24 h, date, heures au-dessus des minutes ; couleur, police et style (verre, plein, contour) partagés avec l'écran de verrouillage.
- **Disposition** : 3 à 6 colonnes, 3 à 8 lignes, mode Pages ou Tiroir (balayage vers le haut), dock de 3 à 6 icônes, barre de recherche.
- Fond d'écran, vidéo, neige, guirlande et musique : indépendants du verrouillage pour le fond, communs pour les réglages d'effets (interrupteurs séparés pour l'accueil).
Le déverrouillage de l'écran de verrouillage ramène à cet accueil.

### Sauvegarde de l'écran de verrouillage, fond d'écran par fond d'écran
Appui long > Personnaliser > Réglages > Écran > « Sauvegarde par fond d'écran ». Chaque fond (photo, vidéo ou fond intégré) garde SA personnalisation de l'écran de verrouillage : horloge (taille, style, couleur, police, compacte, empilée), widgets, effet de profondeur, intensité du verre, style des notifications, effets de Noël et musique de fond.
- Avec « Mémoriser séparément pour chaque fond » (activé par défaut), changer de fond garde les réglages de l'ancien et reprend ceux du nouveau ; un nouveau fond part des réglages du fond précédent puis évolue seul.
- « Sauvegarder pour ce fond », « Restaurer », « Supprimer », et « Appliquer celle d'un autre fond… » pour copier les réglages d'un fond vers l'actuel.
- Une pastille 💾 apparaît sur les fonds qui ont une sauvegarde dans la galerie.
Les réglages d'accueil ont leur propre sauvegarde par fond (voir plus haut).

### Widgets d'autres applis
Sur l'accueil : Réglages de l'accueil > « Widgets d'autres applis » (ou balayage vers la droite). Un panneau « Widgets » s'ouvre : « ＋ Ajouter » liste les widgets Android de toutes vos applis (météo, agenda, musique…), « ✕ » en retire un. Ils sont mémorisés.

### Sauvegardes de l'accueil, fond d'écran par fond d'écran
Réglages de l'accueil > « Sauvegardes (par fond d'écran) » : chaque fond (photo, vidéo ou fond intégré) a sa propre disposition (icônes, dossiers, pages, dock), son style d'icônes, son heure et ses widgets d'accueil. Quand « Mémoriser l'accueil séparément pour chaque fond » est activé, changer de fond d'écran garde l'accueil de l'ancien et reprend celui du nouveau. On peut aussi sauvegarder, restaurer ou supprimer à la main, ou appliquer la disposition d'un autre fond.

### Notifications (écran de verrouillage)
Notifications en verre fumé, regroupées par appli (touchez une pile pour la déplier), balayage vers la gauche pour effacer, animations d'entrée et de sortie fluides. Le texte des messageries (WhatsApp, Messages…) est lu correctement. Le mode édition de l'écran de verrouillage affiche exactement la même mise en page que le résultat final.

### Vidéo en fond
Réglages > Écran > « Importer une vidéo » : la vidéo joue en boucle, plein écran, sous l'horloge et les widgets. Son coupé par défaut (Réglages > « Son et musique » pour l'activer). Pas d'effet de profondeur sur les vidéos. « Assombrir le fond » (Réglages > Effets) aide à lire l'heure sur une vidéo claire.

### Effets de Noël
Réglages > Écran > « Effets de Noël » : neige entièrement réglable (quantité, tailles min/max, vitesse, vent, rafales, balancement, opacité, forme, couleur ou multicolore, profondeur, flocons flous, rotation, lueur, vent selon le gyroscope, neige au sol, devant/derrière l'horloge, bouton Tempête, préréglages) et guirlande lumineuse (palette, clignotement, taille, courbure).

### Son
Réglages > Écran > « Son et musique » : sons d'interface (clavier, déverrouillage), musique de fond (carillon « Jingle Bells », vent d'hiver ou votre propre fichier audio, qui boucle tant que l'écran est affiché) et son de la vidéo.

### Notifications et lecteur
- Les notifications affichent la **vraie icône de l'appli** qui les envoie.
- Un **lecteur multimédia** façon iOS s'affiche sur l'écran de verrouillage dès qu'une appli joue (Spotify, YouTube Music, etc.) : pochette, titre, artiste, barre de progression (touchez pour avancer), précédent / lecture / suivant, volume. Il demande l'accès aux notifications (déjà nécessaire pour les notifications).

### Rapidité
Les notifications arrivent maintenant instantanément (plus d'attente de quelques secondes), la liste des applis et leurs icônes sont mises en cache (l'accueil s'affiche tout de suite) et les icônes sont envoyées par lots.

### Quitter l'appli
- Fermer l'appli depuis les applis récentes arrête aussi le verrouillage (rouvrez l'appli pour le relancer).
- Réglages > « Rester actif en arrière-plan » : garde le service actif (et relancé au démarrage du téléphone) même si l'appli est fermée.
- Réglages > « Quitter l'application » ou le bouton « Arrêter » de la notification : arrêt immédiat.

### Remarques
- Le verrouillage réel (code, empreinte) reste géré par Android : l'appli s'affiche par-dessus, et un balayage vers le haut demande votre code / empreinte, puis se ferme.
- Sur certains téléphones (Xiaomi, Oppo, Samsung...), il faut aussi autoriser « démarrage automatique » et désactiver l'économie de batterie pour l'appli.
- Le détourage des photos utilise le modèle ML Kit des services Google Play (téléchargé automatiquement au premier usage, internet nécessaire une fois).
- Pour modifier l'interface : `app/src/main/assets/index.html`.

### Nouveautés : personnalisation avancée de l'écran de verrouillage
Appui long > Personnaliser > Réglages > Écran > « Plus d'options de personnalisation » :
- **Date** : afficher/masquer, format (Lundi 12 octobre, Lun. 12 oct., 12/10/2026, Lundi), au-dessus ou sous l'heure, casse, taille, opacité, couleur.
- **Heure** : alignement gauche/centre/droite, position verticale, format 12 h, halo lumineux, polices supplémentaires (Fin, Très fin, Manuscrit, Fun) et **deux couleurs** : heures d'une couleur, minutes d'une autre, deux points au choix (feuille « Couleurs, police et style de l'heure », interrupteur « Deux couleurs »). Fonctionne aussi sur l'écran d'accueil.
- **Widgets** : afficher/masquer, au-dessus ou sous l'heure, taille 60 à 150 %.
- **Raccourcis du bas** : taille, verre ou transparent, et pour chaque bouton : lampe torche, appareil photo, n'importe quelle appli installée, ou aucun.
- **Lecteur multimédia** : affichage complet ou compact (double-touchez le lecteur pour basculer). Pochette et fond teintés aux couleurs de la musique, égaliseur animé, barre de lecture qui grossit au toucher, touchez la pochette pour ouvrir l'appli de musique.
- **Indice de déverrouillage** : afficher/masquer, texte personnalisé.
- **Fond d'écran** : flou, luminosité, contraste, saturation, vignettage, teinte colorée (verrouillage et accueil, séparément). Ces réglages sont mémorisés par fond d'écran avec la sauvegarde.
Fluidité : l'horloge n'est plus redessinée chaque seconde, clavier de code plus réactif (touches à rebond, onde de points, appui long sur « Supprimer » pour tout effacer), notifications à inertie (balayage rapide pour effacer), animation d'apparition au réveil de l'écran.

### Bibliothèque de fonds d'écran en ligne
Réglages de l'écran de verrouillage (onglet Écran) ou Réglages de l'accueil > Ambiance > « Fonds d'écran en ligne ». On parcourt des fonds verticaux, on touche pour voir l'aperçu, puis « Utiliser comme fond d'écran » ou « Ajouter à mes fonds » (ils rejoignent la galerie comme vos photos, avec profondeur et sauvegardes par fond).
- Sans clé : Wallhaven (recherche par mot et catégories, contenu tout public), Bing du jour, Photos (Picsum), NASA.
- Avec une clé gratuite (à coller en bas de la fenêtre) : Unsplash, Pixabay.
- « Importer depuis un lien » : collez le lien direct d'une image (https://…).
- Pinterest : pas d'accès libre à ses images (pas d'API publique, récupération automatique interdite par ses conditions). Appui long sur l'image Pinterest > « Copier l'adresse de l'image » > coller dans « Importer depuis un lien ».
Technique : MainActivity.kt expose Android.httpGet(url, headers, id) et Android.fetchImage(url, id) (HTTPS uniquement, image réduite à 1800 px max) ; la page reçoit le résultat par onHttp / onHttpImg. La permission INTERNET est déjà déclarée.

### Notifications de musique et Flickr
- Les notifications des lecteurs de musique (Metrolist, Spotify…) ne s'affichent plus sous le lecteur : il les remplace. Côté Android elles sont filtrées (catégorie transport / MediaStyle), côté page un filtre supplémentaire retire le doublon du morceau en cours.
- Bibliothèque de fonds d'écran : Flickr ajouté (clé gratuite sur flickr.com/services/apps/create, photos sous licences ouvertes, contenu tout public, verticales en priorité).

### Notifications qui défilent comme sur iOS, nouvelles sources, styles du fond
- Les notifications forment maintenant une vraie liste qui défile (inertie, comme sur iPhone) : elle démarre sous l'horloge, et en la faisant glisser vers le haut elle passe devant l'horloge, qui s'estompe, pendant que le fond se floute (fondu en haut de la liste). Plus de « notifications masquées » : tout est accessible en défilant. Le balayage vers la gauche pour effacer reste possible. Nombre maximum relevé (30 par défaut).
- Bibliothèque de fonds : ajout d'Openverse, Wikimedia Commons, Art Institute of Chicago et NASA Images (sans clé), en plus de Flickr.
- Styles du fond (comme « Natural » d'iOS 27), dans Plus d'options > Fond d'écran : Naturel, Noir et blanc, Duo, Dynamique, Studio, Doux, Nuit.
- Panneau de l'horloge : chaque police est montrée avec un aperçu « 12 ».

### Mise à jour : notifications, lecteur, widgets
- Flickr et Pexels retirés de la bibliothèque de fonds (restent : Wallhaven, Bing, Photos, NASA, Openverse, Wikimedia, Art Institute, NASA Images, et Unsplash / Pixabay avec une clé gratuite facultative).
- Notifications : appui long sur une notification (ou une pile) = aperçu agrandi avec texte complet et boutons Ouvrir / Effacer / Fermer. Les heures (« à l'instant », « 5 min ») se mettent à jour toutes seules. « Effacer tout » efface en cascade. Petit retour haptique quand une nouvelle notification arrive. La liste est de nouveau ancrée en bas (au-dessus des boutons) même sans lecteur.
- Lecteur : balayage gauche/droite sur le lecteur = morceau suivant / précédent. Pochette par défaut quand l'appli n'en fournit pas. Curseur de volume en verre. Seule la pochette ouvre l'appli de musique (plus de déclenchement par erreur en touchant le titre). Affichage Auto (par défaut) : le lecteur passe en compact tout seul quand il manque de place. Une erreur du lecteur ne peut plus bloquer le reste de l'écran.
- Widgets : nouvelle position « Près des boutons » (au-dessus de la lampe et de l'appareil photo), les notifications s'arrêtent au-dessus.
