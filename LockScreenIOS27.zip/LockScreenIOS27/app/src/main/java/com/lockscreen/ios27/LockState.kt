package com.lockscreen.ios27

/** État du verrouillage partagé entre le service et l'écran. */
object LockState {
    /** Vrai entre l'extinction de l'écran et le déverrouillage. */
    @Volatile
    var engaged = false

    /** Vrai juste avant que l'appli ouvre elle-même un autre écran (appareil photo, sélecteur...). */
    @Volatile
    var allowLeave = false

    @Volatile
    var windowStart = 0L

    @Volatile
    var bounces = 0

    @Volatile
    var lastBounce = 0L
}
