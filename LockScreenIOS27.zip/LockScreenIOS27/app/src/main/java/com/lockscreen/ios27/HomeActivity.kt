package com.lockscreen.ios27

/** Écran d'accueil de l'appli : même page, en mode accueil (applis, dock, widgets, fond animé, neige, son). */
class HomeActivity : MainActivity() {
    override val homeMode: Boolean
        get() = true
}
