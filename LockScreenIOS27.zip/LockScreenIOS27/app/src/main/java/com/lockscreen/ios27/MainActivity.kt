package com.lockscreen.ios27

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.KeyguardManager
import android.app.Notification
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageDecoder
import android.graphics.Color
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.MediaStore
import android.provider.Settings
import android.util.Base64
import android.view.HapticFeedbackConstants
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.core.app.NotificationManagerCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.webkit.WebViewAssetLoader
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.segmentation.subject.SubjectSegmentation
import com.google.mlkit.vision.segmentation.subject.SubjectSegmenterOptions
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream

class MainActivity : Activity() {

    private lateinit var web: WebView
    private var chooser: ValueCallback<Array<Uri>>? = null
    private var visible = false

    // Quand le téléphone est déverrouillé (empreinte, code...), l'écran de verrouillage se ferme
    private val presentReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            LockState.engaged = false
            if (visible) moveTaskToBack(true)
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        if (Build.VERSION.SDK_INT >= 28) {
            window.attributes.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }

        web = WebView(this)
        web.setBackgroundColor(Color.BLACK)
        setContentView(web)

        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = false

        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(
                view: WebView?,
                request: WebResourceRequest?
            ): WebResourceResponse? {
                val u = request?.url ?: return null
                return loader.shouldInterceptRequest(u)
            }
        }

        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: FileChooserParams?
            ): Boolean {
                chooser?.onReceiveValue(null)
                chooser = filePathCallback
                val i = Intent(Intent.ACTION_GET_CONTENT)
                i.addCategory(Intent.CATEGORY_OPENABLE)
                i.type = "image/*"
                i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
                LockState.allowLeave = true
                return try {
                    startActivityForResult(Intent.createChooser(i, "Photo"), REQ_PICK)
                    true
                } catch (e: Exception) {
                    chooser?.onReceiveValue(null)
                    chooser = null
                    false
                }
            }
        }

        web.addJavascriptInterface(Bridge(), "Android")

        ViewCompat.setOnApplyWindowInsetsListener(web) { _, insets ->
            val b = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            val d = resources.displayMetrics.density
            js("window.setInsets&&setInsets(" + (b.top / d) + "," + (b.bottom / d) + ")")
            val ime = insets.getInsets(WindowInsetsCompat.Type.ime())
            val kb = maxOf(0, ime.bottom - b.bottom)
            js("window.setKb&&setKb(" + (kb / d) + ")")
            insets
        }

        web.loadUrl("https://appassets.androidplatform.net/assets/index.html")

        val f = IntentFilter(Intent.ACTION_USER_PRESENT)
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(presentReceiver, f, Context.RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(presentReceiver, f)
        }
    }

    override fun onDestroy() {
        try {
            unregisterReceiver(presentReceiver)
        } catch (e: Exception) {
        }
        super.onDestroy()
    }

    override fun onResume() {
        super.onResume()
        visible = true
        LockState.allowLeave = false
        // L'écran de verrouillage est considéré verrouillé dès qu'il est affiché, jusqu'au balayage vers le haut
        LockState.engaged = true
        // Relance le service d'allumage si l'autorisation d'affichage est déjà accordée
        if (Settings.canDrawOverlays(this)) {
            try {
                LockService.start(this)
            } catch (e: Exception) {
            }
        }
        js("window.onPerm&&onPerm()")
    }

    override fun onPause() {
        visible = false
        super.onPause()
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        js("window.onPerm&&onPerm()")
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == REQ_PICK) {
            val cb = chooser
            chooser = null
            val uris = ArrayList<Uri>()
            if (resultCode == RESULT_OK && data != null) {
                val clip = data.clipData
                if (clip != null) {
                    for (i in 0 until clip.itemCount) uris.add(clip.getItemAt(i).uri)
                } else {
                    val u = data.data
                    if (u != null) uris.add(u)
                }
            }
            // On annule côté WebView : les photos sont décodées ici et envoyées à la page
            cb?.onReceiveValue(null)
            if (uris.isNotEmpty()) {
                js("window.onPhotoStart&&onPhotoStart(" + uris.size + ")")
                Thread {
                    for (u in uris) {
                        val d = readPhoto(u)
                        if (d != null) js("window.onPhoto&&onPhoto('" + d + "')")
                        else js("window.onPhoto&&onPhoto(null)")
                    }
                }.start()
            }
            return
        }
        super.onActivityResult(requestCode, resultCode, data)
    }

    /** Lit une photo (JPEG, PNG, HEIC...), la remet à l'endroit et la réduit à 1600 px max. */
    private fun readPhoto(uri: Uri): String? {
        return try {
            var bmp: Bitmap? = null
            if (Build.VERSION.SDK_INT >= 28) {
                val src = ImageDecoder.createSource(contentResolver, uri)
                bmp = ImageDecoder.decodeBitmap(src) { decoder, info, _ ->
                    decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
                    val m = maxOf(info.size.width, info.size.height)
                    if (m > 1600) decoder.setTargetSampleSize(maxOf(1, m / 1600))
                }
            } else {
                contentResolver.openInputStream(uri)?.use { bmp = BitmapFactory.decodeStream(it) }
            }
            val b = bmp ?: return null
            val m = maxOf(b.width, b.height)
            val out = if (m > 1800) {
                val k = 1800f / m
                Bitmap.createScaledBitmap(b, (b.width * k).toInt(), (b.height * k).toInt(), true)
            } else b
            val baos = ByteArrayOutputStream()
            out.compress(Bitmap.CompressFormat.JPEG, 85, baos)
            "data:image/jpeg;base64," + Base64.encodeToString(baos.toByteArray(), Base64.NO_WRAP)
        } catch (e: Throwable) {
            null
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        // Verrouillage strict : Retour ne permet pas de quitter l'écran de verrouillage
        if (LockState.engaged && Prefs.strict(this)) return
        val km = getSystemService(KEYGUARD_SERVICE) as KeyguardManager
        if (!km.isKeyguardLocked) {
            super.onBackPressed()
        }
    }

    /**
     * Accueil ou Récents pressé : tant que le téléphone est verrouillé (mode strict),
     * l'écran de verrouillage revient aussitôt au premier plan.
     * Si l'utilisateur insiste (4 tentatives en 10 s), on le laisse sortir pour ne jamais le piéger.
     */
    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (LockState.allowLeave) return
        bounce()
    }

    override fun onStop() {
        super.onStop()
        if (LockState.allowLeave) return
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        if (!pm.isInteractive) return
        bounce()
    }

    private fun bounce() {
        if (!LockState.engaged || !Prefs.strict(this) || isFinishing) return
        val now = System.currentTimeMillis()
        if (now - LockState.lastBounce < 400) return
        if (now - LockState.windowStart > 10_000) {
            LockState.windowStart = now
            LockState.bounces = 0
        }
        if (LockState.bounces >= 3) {
            LockState.engaged = false
            return
        }
        LockState.bounces++
        LockState.lastBounce = now
        web.postDelayed({
            try {
                startActivity(
                    Intent(this, MainActivity::class.java).addFlags(
                        Intent.FLAG_ACTIVITY_NEW_TASK or
                            Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or
                            Intent.FLAG_ACTIVITY_SINGLE_TOP
                    )
                )
            } catch (e: Exception) {
            }
        }, 40)
    }

    private fun js(code: String) {
        runOnUiThread { web.evaluateJavascript(code, null) }
    }

    inner class Bridge {

        @JavascriptInterface
        fun status(): String {
            val photoPerm = if (Build.VERSION.SDK_INT >= 33)
                Manifest.permission.READ_MEDIA_IMAGES else Manifest.permission.READ_EXTERNAL_STORAGE
            val o = JSONObject()
            o.put("photos", checkSelfPermission(photoPerm) == PackageManager.PERMISSION_GRANTED)
            o.put(
                "notif",
                Build.VERSION.SDK_INT < 33 ||
                    checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
            )
            o.put("listener", NotificationManagerCompat.getEnabledListenerPackages(this@MainActivity).contains(packageName))
            o.put("overlay", Settings.canDrawOverlays(this@MainActivity))
            val pm = getSystemService(POWER_SERVICE) as PowerManager
            o.put("battery", pm.isIgnoringBatteryOptimizations(packageName))
            o.put("persist", Prefs.persist(this@MainActivity))
            o.put("strict", Prefs.strict(this@MainActivity))
            return o.toString()
        }

        @JavascriptInterface
        fun requestPhotos() {
            runOnUiThread {
                LockState.allowLeave = true
                val p = if (Build.VERSION.SDK_INT >= 33)
                    Manifest.permission.READ_MEDIA_IMAGES else Manifest.permission.READ_EXTERNAL_STORAGE
                requestPermissions(arrayOf(p), 2)
            }
        }

        @JavascriptInterface
        fun requestNotif() {
            runOnUiThread {
                LockState.allowLeave = true
                if (Build.VERSION.SDK_INT >= 33) {
                    requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 3)
                }
            }
        }

        @JavascriptInterface
        fun openListener() {
            runOnUiThread {
                LockState.allowLeave = true
                startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
            }
        }

        @JavascriptInterface
        fun openOverlay() {
            runOnUiThread {
                LockState.allowLeave = true
                startActivity(
                    Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
                )
            }
        }

        @JavascriptInterface
        fun openBattery() {
            runOnUiThread {
                LockState.allowLeave = true
                try {
                    startActivity(
                        Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))
                    )
                } catch (e: Exception) {
                    startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
                }
            }
        }

        @JavascriptInterface
        fun setStrict(v: Boolean) {
            Prefs.setStrict(this@MainActivity, v)
        }

        @JavascriptInterface
        fun setPersist(v: Boolean) {
            Prefs.setPersist(this@MainActivity, v)
        }

        /** Quitte complètement : arrête le service et ferme l'appli (elle disparaît des applis récentes). */
        @JavascriptInterface
        fun quit() {
            runOnUiThread {
                LockState.engaged = false
                try {
                    stopService(Intent(this@MainActivity, LockService::class.java))
                } catch (e: Exception) {
                }
                finishAndRemoveTask()
            }
        }

        @JavascriptInterface
        fun startService() {
            runOnUiThread {
                try {
                    LockService.start(this@MainActivity)
                } catch (e: Exception) {
                }
            }
        }

        @JavascriptInterface
        fun notifications(): String {
            val arr = JSONArray()
            val svc = NotifService.instance ?: return "[]"
            try {
                val list = svc.activeNotifications ?: return "[]"
                for (sbn in list.sortedByDescending { it.postTime }) {
                    if (sbn.packageName == packageName) continue
                    val n = sbn.notification
                    if ((n.flags and Notification.FLAG_GROUP_SUMMARY) != 0) continue
                    if (sbn.isOngoing) continue
                    val ex = n.extras
                    val title = ex.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: ""
                    val text = (ex.getCharSequence(Notification.EXTRA_BIG_TEXT)
                        ?: ex.getCharSequence(Notification.EXTRA_TEXT))?.toString() ?: ""
                    if (title.isEmpty() && text.isEmpty()) continue
                    val label = try {
                        packageManager.getApplicationLabel(
                            packageManager.getApplicationInfo(sbn.packageName, 0)
                        ).toString()
                    } catch (e: Exception) {
                        sbn.packageName
                    }
                    val o = JSONObject()
                    o.put("key", sbn.key)
                    o.put("app", label)
                    o.put("title", title)
                    o.put("text", text)
                    o.put("time", sbn.postTime)
                    arr.put(o)
                }
            } catch (e: Exception) {
            }
            return arr.toString()
        }

        @JavascriptInterface
        fun dismiss(key: String) {
            try {
                NotifService.instance?.cancelNotification(key)
            } catch (e: Exception) {
            }
        }

        @JavascriptInterface
        fun haptic(kind: String) {
            runOnUiThread {
                val c = when (kind) {
                    "ok" -> if (Build.VERSION.SDK_INT >= 30) HapticFeedbackConstants.CONFIRM else HapticFeedbackConstants.LONG_PRESS
                    "no" -> if (Build.VERSION.SDK_INT >= 30) HapticFeedbackConstants.REJECT else HapticFeedbackConstants.LONG_PRESS
                    else -> HapticFeedbackConstants.KEYBOARD_TAP
                }
                web.performHapticFeedback(c)
            }
        }

        /** Ouvre la notification touchée (après déverrouillage). */
        @JavascriptInterface
        fun openNotif(key: String) {
            runOnUiThread {
                val svc = NotifService.instance
                val sbn = svc?.activeNotifications?.firstOrNull { it.key == key }
                val pi = sbn?.notification?.contentIntent
                val autoCancel = sbn != null && (sbn.notification.flags and Notification.FLAG_AUTO_CANCEL) != 0
                val go = {
                    LockState.engaged = false
                    try {
                        pi?.send()
                    } catch (e: Exception) {
                    }
                    if (autoCancel) {
                        try {
                            svc?.cancelNotification(key)
                        } catch (e: Exception) {
                        }
                    }
                    moveTaskToBack(true)
                }
                val km = getSystemService(KEYGUARD_SERVICE) as KeyguardManager
                if (km.isKeyguardLocked) {
                    km.requestDismissKeyguard(
                        this@MainActivity,
                        object : KeyguardManager.KeyguardDismissCallback() {
                            override fun onDismissSucceeded() {
                                go()
                            }
                        }
                    )
                } else {
                    go()
                }
            }
        }

        @JavascriptInterface
        fun battery(): Int {
            val bm = getSystemService(BATTERY_SERVICE) as BatteryManager
            return bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        }

        @JavascriptInterface
        fun torch(on: Boolean) {
            try {
                val cm = getSystemService(CAMERA_SERVICE) as CameraManager
                for (id in cm.cameraIdList) {
                    val flash = cm.getCameraCharacteristics(id).get(CameraCharacteristics.FLASH_INFO_AVAILABLE)
                    if (flash == true) {
                        cm.setTorchMode(id, on)
                        break
                    }
                }
            } catch (e: Exception) {
            }
        }

        @JavascriptInterface
        fun camera() {
            runOnUiThread {
                LockState.allowLeave = true
                try {
                    startActivity(
                        Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA_SECURE)
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                } catch (e: Exception) {
                    try {
                        startActivity(
                            Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)
                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        )
                    } catch (e2: Exception) {
                    }
                }
            }
        }

        @JavascriptInterface
        fun unlock() {
            runOnUiThread {
                LockState.engaged = false
                val km = getSystemService(KEYGUARD_SERVICE) as KeyguardManager
                if (km.isKeyguardLocked) {
                    km.requestDismissKeyguard(
                        this@MainActivity,
                        object : KeyguardManager.KeyguardDismissCallback() {
                            override fun onDismissSucceeded() {
                                moveTaskToBack(true)
                            }
                        }
                    )
                } else {
                    moveTaskToBack(true)
                }
            }
        }

        /** Détourage du sujet (ML Kit) ; renvoie un PNG transparent via window.onSeg(id, dataUrl). */
        @JavascriptInterface
        fun segment(dataUrl: String, id: String) {
            Thread {
                try {
                    val bytes = Base64.decode(dataUrl.substringAfter(","), Base64.DEFAULT)
                    val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                    val opts = SubjectSegmenterOptions.Builder().enableForegroundBitmap().build()
                    val seg = SubjectSegmentation.getClient(opts)
                    seg.process(InputImage.fromBitmap(bmp, 0))
                        .addOnSuccessListener { r ->
                            val fg = r.foregroundBitmap
                            if (fg == null) {
                                js("window.onSeg&&onSeg('$id',null)")
                            } else {
                                val out = ByteArrayOutputStream()
                                fg.compress(Bitmap.CompressFormat.PNG, 100, out)
                                val b64 = Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
                                js("window.onSeg&&onSeg('$id','data:image/png;base64,$b64')")
                            }
                            seg.close()
                        }
                        .addOnFailureListener {
                            js("window.onSeg&&onSeg('$id',null)")
                            seg.close()
                        }
                } catch (e: Exception) {
                    js("window.onSeg&&onSeg('$id',null)")
                }
            }.start()
        }
    }

    companion object {
        private const val REQ_PICK = 1
    }
}
