package com.lockscreen.ios27

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.KeyguardManager
import android.app.Notification
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.MediaStore
import android.provider.Settings
import android.util.Base64
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.core.app.NotificationManagerCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.webkit.WebViewAssetLoader
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.segmentation.subject.SubjectSegmentation
import com.google.mlkit.vision.segmentation.subject.SubjectSegmenterOptions
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream

class MainActivity : Activity() {

    private lateinit var web: WebView
    private var chooser: ValueCallback<Array<Uri>>? = null

    // Quand le téléphone est déverrouillé (empreinte, code...), l'écran de verrouillage se ferme
    private val presentReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            finish()
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        if (Build.VERSION.SDK_INT >= 28) {
            window.attributes.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }

        web = WebView(this)
        web.setBackgroundColor(Color.BLACK)
        setContentView(web)

        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = false

        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(
                view: WebView?,
                request: WebResourceRequest?
            ): WebResourceResponse? {
                val u = request?.url ?: return null
                return loader.shouldInterceptRequest(u)
            }
        }

        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: FileChooserParams?
            ): Boolean {
                chooser?.onReceiveValue(null)
                chooser = filePathCallback
                val i = Intent(Intent.ACTION_GET_CONTENT)
                i.addCategory(Intent.CATEGORY_OPENABLE)
                i.type = "image/*"
                i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
                return try {
                    startActivityForResult(Intent.createChooser(i, "Photo"), REQ_PICK)
                    true
                } catch (e: Exception) {
                    chooser?.onReceiveValue(null)
                    chooser = null
                    false
                }
            }
        }

        web.addJavascriptInterface(Bridge(), "Android")

        ViewCompat.setOnApplyWindowInsetsListener(web) { _, insets ->
            val b = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            val d = resources.displayMetrics.density
            js("window.setInsets&&setInsets(" + (b.top / d) + "," + (b.bottom / d) + ")")
            insets
        }

        web.loadUrl("https://appassets.androidplatform.net/assets/index.html")

        val f = IntentFilter(Intent.ACTION_USER_PRESENT)
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(presentReceiver, f, Context.RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(presentReceiver, f)
        }
    }

    override fun onDestroy() {
        try {
            unregisterReceiver(presentReceiver)
        } catch (e: Exception) {
        }
        super.onDestroy()
    }

    override fun onResume() {
        super.onResume()
        // Relance le service d'allumage si l'autorisation d'affichage est déjà accordée
        if (Settings.canDrawOverlays(this)) {
            try {
                LockService.start(this)
            } catch (e: Exception) {
            }
        }
        js("window.onPerm&&onPerm()")
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        js("window.onPerm&&onPerm()")
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == REQ_PICK) {
            chooser?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data))
            chooser = null
            return
        }
        super.onActivityResult(requestCode, resultCode, data)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        val km = getSystemService(KEYGUARD_SERVICE) as KeyguardManager
        if (!km.isKeyguardLocked) {
            super.onBackPressed()
        }
    }

    private fun js(code: String) {
        runOnUiThread { web.evaluateJavascript(code, null) }
    }

    inner class Bridge {

        @JavascriptInterface
        fun status(): String {
            val photoPerm = if (Build.VERSION.SDK_INT >= 33)
                Manifest.permission.READ_MEDIA_IMAGES else Manifest.permission.READ_EXTERNAL_STORAGE
            val o = JSONObject()
            o.put("photos", checkSelfPermission(photoPerm) == PackageManager.PERMISSION_GRANTED)
            o.put(
                "notif",
                Build.VERSION.SDK_INT < 33 ||
                    checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
            )
            o.put("listener", NotificationManagerCompat.getEnabledListenerPackages(this@MainActivity).contains(packageName))
            o.put("overlay", Settings.canDrawOverlays(this@MainActivity))
            val pm = getSystemService(POWER_SERVICE) as PowerManager
            o.put("battery", pm.isIgnoringBatteryOptimizations(packageName))
            return o.toString()
        }

        @JavascriptInterface
        fun requestPhotos() {
            runOnUiThread {
                val p = if (Build.VERSION.SDK_INT >= 33)
                    Manifest.permission.READ_MEDIA_IMAGES else Manifest.permission.READ_EXTERNAL_STORAGE
                requestPermissions(arrayOf(p), 2)
            }
        }

        @JavascriptInterface
        fun requestNotif() {
            runOnUiThread {
                if (Build.VERSION.SDK_INT >= 33) {
                    requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 3)
                }
            }
        }

        @JavascriptInterface
        fun openListener() {
            runOnUiThread { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }
        }

        @JavascriptInterface
        fun openOverlay() {
            runOnUiThread {
                startActivity(
                    Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
                )
            }
        }

        @JavascriptInterface
        fun openBattery() {
            runOnUiThread {
                try {
                    startActivity(
                        Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))
                    )
                } catch (e: Exception) {
                    startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
                }
            }
        }

        @JavascriptInterface
        fun startService() {
            runOnUiThread {
                try {
                    LockService.start(this@MainActivity)
                } catch (e: Exception) {
                }
            }
        }

        @JavascriptInterface
        fun notifications(): String {
            val arr = JSONArray()
            val svc = NotifService.instance ?: return "[]"
            try {
                val list = svc.activeNotifications ?: return "[]"
                for (sbn in list.sortedByDescending { it.postTime }) {
                    if (sbn.packageName == packageName) continue
                    val n = sbn.notification
                    if ((n.flags and Notification.FLAG_GROUP_SUMMARY) != 0) continue
                    if (sbn.isOngoing) continue
                    val ex = n.extras
                    val title = ex.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: ""
                    val text = (ex.getCharSequence(Notification.EXTRA_BIG_TEXT)
                        ?: ex.getCharSequence(Notification.EXTRA_TEXT))?.toString() ?: ""
                    if (title.isEmpty() && text.isEmpty()) continue
                    val label = try {
                        packageManager.getApplicationLabel(
                            packageManager.getApplicationInfo(sbn.packageName, 0)
                        ).toString()
                    } catch (e: Exception) {
                        sbn.packageName
                    }
                    val o = JSONObject()
                    o.put("key", sbn.key)
                    o.put("app", label)
                    o.put("title", title)
                    o.put("text", text)
                    o.put("time", sbn.postTime)
                    arr.put(o)
                }
            } catch (e: Exception) {
            }
            return arr.toString()
        }

        @JavascriptInterface
        fun dismiss(key: String) {
            try {
                NotifService.instance?.cancelNotification(key)
            } catch (e: Exception) {
            }
        }

        @JavascriptInterface
        fun battery(): Int {
            val bm = getSystemService(BATTERY_SERVICE) as BatteryManager
            return bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        }

        @JavascriptInterface
        fun torch(on: Boolean) {
            try {
                val cm = getSystemService(CAMERA_SERVICE) as CameraManager
                for (id in cm.cameraIdList) {
                    val flash = cm.getCameraCharacteristics(id).get(CameraCharacteristics.FLASH_INFO_AVAILABLE)
                    if (flash == true) {
                        cm.setTorchMode(id, on)
                        break
                    }
                }
            } catch (e: Exception) {
            }
        }

        @JavascriptInterface
        fun camera() {
            runOnUiThread {
                try {
                    startActivity(
                        Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA_SECURE)
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                } catch (e: Exception) {
                    try {
                        startActivity(
                            Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)
                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        )
                    } catch (e2: Exception) {
                    }
                }
            }
        }

        @JavascriptInterface
        fun unlock() {
            runOnUiThread {
                val km = getSystemService(KEYGUARD_SERVICE) as KeyguardManager
                if (km.isKeyguardLocked) {
                    km.requestDismissKeyguard(
                        this@MainActivity,
                        object : KeyguardManager.KeyguardDismissCallback() {
                            override fun onDismissSucceeded() {
                                finish()
                            }
                        }
                    )
                } else {
                    finish()
                }
            }
        }

        /** Détourage du sujet (ML Kit) ; renvoie un PNG transparent via window.onSeg(id, dataUrl). */
        @JavascriptInterface
        fun segment(dataUrl: String, id: String) {
            Thread {
                try {
                    val bytes = Base64.decode(dataUrl.substringAfter(","), Base64.DEFAULT)
                    val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                    val opts = SubjectSegmenterOptions.Builder().enableForegroundBitmap().build()
                    val seg = SubjectSegmentation.getClient(opts)
                    seg.process(InputImage.fromBitmap(bmp, 0))
                        .addOnSuccessListener { r ->
                            val fg = r.foregroundBitmap
                            if (fg == null) {
                                js("window.onSeg&&onSeg('$id',null)")
                            } else {
                                val out = ByteArrayOutputStream()
                                fg.compress(Bitmap.CompressFormat.PNG, 100, out)
                                val b64 = Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
                                js("window.onSeg&&onSeg('$id','data:image/png;base64,$b64')")
                            }
                            seg.close()
                        }
                        .addOnFailureListener {
                            js("window.onSeg&&onSeg('$id',null)")
                            seg.close()
                        }
                } catch (e: Exception) {
                    js("window.onSeg&&onSeg('$id',null)")
                }
            }.start()
        }
    }

    companion object {
        private const val REQ_PICK = 1
    }
}
