package com.lockscreen.ios27

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/** Donne à l'écran de verrouillage l'accès aux notifications du téléphone, et le prévient aussitôt qu'une notification arrive ou disparaît. */
class NotifService : NotificationListenerService() {

    override fun onListenerConnected() {
        instance = this
        onChange?.invoke()
    }

    override fun onListenerDisconnected() {
        if (instance === this) instance = null
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        onChange?.invoke()
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification?) {
        onChange?.invoke()
    }

    companion object {
        @Volatile
        var instance: NotifService? = null

        @Volatile
        var onChange: (() -> Unit)? = null
    }
}
