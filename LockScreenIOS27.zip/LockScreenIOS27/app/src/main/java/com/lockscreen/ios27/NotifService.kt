package com.lockscreen.ios27

import android.content.ComponentName
import android.os.Handler
import android.os.Looper
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/**
 * Donne à l'écran de verrouillage l'accès aux notifications du téléphone.
 * À chaque changement, la copie NotifStore est relue puis la page est prévenue.
 * Si Android coupe la connexion, on demande aussitôt de se reconnecter.
 */
class NotifService : NotificationListenerService() {

    private val handler = Handler(Looper.getMainLooper())
    private val pending = Runnable { doRefresh() }

    private fun schedule() {
        handler.removeCallbacks(pending)
        handler.postDelayed(pending, 60)
    }

    fun doRefresh() {
        try {
            val list: Array<StatusBarNotification>? = try {
                activeNotifications
            } catch (e: Exception) {
                null
            }
            val rank = try {
                currentRanking
            } catch (e: Exception) {
                null
            }
            NotifStore.refresh(applicationContext, list, rank)
        } catch (e: Exception) {
            NotifStore.error = e.javaClass.simpleName + ": " + (e.message ?: "")
        }
        onChange?.invoke()
    }

    override fun onListenerConnected() {
        instance = this
        doRefresh()
    }

    override fun onListenerDisconnected() {
        if (instance === this) instance = null
        try {
            requestRebind(ComponentName(this, NotifService::class.java))
        } catch (e: Exception) {
        }
        onChange?.invoke()
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        schedule()
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification?) {
        schedule()
    }

    override fun onNotificationRankingUpdate(rankingMap: RankingMap?) {
        schedule()
    }

    companion object {
        @Volatile
        var instance: NotifService? = null

        @Volatile
        var onChange: (() -> Unit)? = null

        /** Relit tout de suite les notifications (utile quand l'écran se rallume). */
        fun refreshNow() {
            instance?.doRefresh()
        }
    }
}
