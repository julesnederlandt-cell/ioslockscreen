package com.lockscreen.ios27

import android.service.notification.NotificationListenerService

/** Donne à l'écran de verrouillage l'accès aux notifications du téléphone. */
class NotifService : NotificationListenerService() {

    override fun onListenerConnected() {
        instance = this
    }

    override fun onListenerDisconnected() {
        if (instance === this) instance = null
    }

    companion object {
        @Volatile
        var instance: NotifService? = null
    }
}
