package com.lockscreen.ios27

import android.content.Context
import android.graphics.Matrix
import android.graphics.SurfaceTexture
import android.media.MediaPlayer
import android.net.Uri
import android.view.Surface
import android.view.TextureView

/** Vidéo de fond : plein écran, recadrée (comme un fond d'écran), jouée sous la page. */
class VideoLayer(context: Context) : TextureView(context), TextureView.SurfaceTextureListener {

    private var mp: MediaPlayer? = null
    private var surface: Surface? = null
    private var uri: Uri? = null
    private var volume = 0f
    private var vw = 0
    private var vh = 0
    private var wantPlay = false

    /** Appelé si la vidéo ne peut pas être lue (fichier supprimé, format inconnu...). */
    var onError: (() -> Unit)? = null

    init {
        surfaceTextureListener = this
        visibility = GONE
    }

    fun play(u: Uri, vol: Float) {
        uri = u
        volume = vol
        wantPlay = true
        visibility = VISIBLE
        if (isAvailable) start()
    }

    fun stop() {
        wantPlay = false
        release()
        visibility = GONE
    }

    fun setVol(v: Float) {
        volume = v
        try {
            mp?.setVolume(v, v)
        } catch (e: Exception) {
        }
    }

    fun pause() {
        try {
            mp?.pause()
        } catch (e: Exception) {
        }
    }

    fun resume() {
        if (!wantPlay) return
        if (mp == null) {
            if (isAvailable) start()
        } else {
            try {
                mp?.start()
            } catch (e: Exception) {
            }
        }
    }

    private fun start() {
        release()
        val u = uri ?: return
        val st = surfaceTexture ?: return
        try {
            val s = Surface(st)
            surface = s
            val p = MediaPlayer()
            p.setSurface(s)
            p.setDataSource(context, u)
            p.isLooping = true
            p.setVolume(volume, volume)
            p.setOnVideoSizeChangedListener { _, w, h ->
                vw = w
                vh = h
                fit()
            }
            p.setOnPreparedListener { it.start() }
            p.setOnErrorListener { _, _, _ ->
                onError?.invoke()
                true
            }
            p.prepareAsync()
            mp = p
        } catch (e: Exception) {
            release()
            onError?.invoke()
        }
    }

    private fun release() {
        try {
            mp?.release()
        } catch (e: Exception) {
        }
        mp = null
        try {
            surface?.release()
        } catch (e: Exception) {
        }
        surface = null
    }

    /** Recadre la vidéo pour remplir l'écran sans la déformer. */
    private fun fit() {
        if (vw == 0 || vh == 0 || width == 0 || height == 0) return
        val k = maxOf(width.toFloat() / vw, height.toFloat() / vh)
        val m = Matrix()
        m.setScale(vw * k / width, vh * k / height, width / 2f, height / 2f)
        setTransform(m)
    }

    override fun onSurfaceTextureAvailable(st: SurfaceTexture, w: Int, h: Int) {
        if (wantPlay) start()
    }

    override fun onSurfaceTextureSizeChanged(st: SurfaceTexture, w: Int, h: Int) {
        fit()
    }

    override fun onSurfaceTextureDestroyed(st: SurfaceTexture): Boolean {
        release()
        return true
    }

    override fun onSurfaceTextureUpdated(st: SurfaceTexture) {}
}
