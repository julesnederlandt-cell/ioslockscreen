package com.lockscreen.ios27

import android.content.Context

/** Réglages simples de l'appli. */
object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("cfg", Context.MODE_PRIVATE)

    /** Vrai = le service reste actif même quand l'appli est fermée depuis les applis récentes. */
    fun persist(c: Context): Boolean = sp(c).getBoolean("persist", false)

    fun setPersist(c: Context, v: Boolean) {
        sp(c).edit().putBoolean("persist", v).apply()
    }
}
