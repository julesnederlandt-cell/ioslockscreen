package com.lockscreen.ios27

import android.content.Context

/** Réglages simples de l'appli. */
object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("cfg", Context.MODE_PRIVATE)

    /** Vrai = le service reste actif même quand l'appli est fermée depuis les applis récentes. */
    fun persist(c: Context): Boolean = sp(c).getBoolean("persist", false)

    /** Vrai = Accueil / Récents / Retour ne permettent pas de quitter l'écran de verrouillage. */
    fun strict(c: Context): Boolean = sp(c).getBoolean("strict", true)

    fun setStrict(c: Context, v: Boolean) {
        sp(c).edit().putBoolean("strict", v).apply()
    }

    fun setPersist(c: Context, v: Boolean) {
        sp(c).edit().putBoolean("persist", v).apply()
    }
}
