package com.lockscreen.ios27

import android.app.Activity
import android.app.AlertDialog
import android.appwidget.AppWidgetHost
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProviderInfo
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/**
 * Panneau de widgets d'autres applis (comme la vue « Aujourd'hui » d'iOS).
 * On y ajoute les widgets Android de n'importe quelle appli ; ils restent mémorisés.
 */
class WidgetPanelActivity : Activity() {

    private lateinit var host: AppWidgetHost
    private lateinit var awm: AppWidgetManager
    private lateinit var box: LinearLayout
    private val ids = ArrayList<Int>()
    private var pending = -1

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        awm = AppWidgetManager.getInstance(this)
        host = AppWidgetHost(this, HOST_ID)

        val root = FrameLayout(this)
        root.fitsSystemWindows = true

        val scroll = ScrollView(this)
        box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(14), dp(64), dp(14), dp(80))
        scroll.addView(box)
        root.addView(scroll, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.setBackgroundColor(Color.parseColor("#B3140F24"))
        bar.setPadding(dp(16), dp(8), dp(8), dp(8))
        val title = TextView(this)
        title.text = "Widgets"
        title.setTextColor(Color.WHITE)
        title.textSize = 22f
        title.setTypeface(null, Typeface.BOLD)
        bar.addView(title, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        bar.addView(button("＋ Ajouter") { chooseProvider() })
        bar.addView(button("OK") { finish() })
        root.addView(bar, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP))

        setContentView(root)
        loadSaved()
    }

    private fun button(label: String, onClick: () -> Unit): TextView {
        val b = TextView(this)
        b.text = label
        b.setTextColor(Color.WHITE)
        b.textSize = 15f
        b.setTypeface(null, Typeface.BOLD)
        b.setPadding(dp(14), dp(10), dp(14), dp(10))
        b.setOnClickListener { onClick() }
        return b
    }

    override fun onStart() {
        super.onStart()
        host.startListening()
    }

    override fun onStop() {
        try {
            host.stopListening()
        } catch (e: Exception) {
        }
        super.onStop()
    }

    private fun prefs() = getSharedPreferences("widgets", MODE_PRIVATE)

    private fun save() {
        prefs().edit().putString("ids", ids.joinToString(",")).apply()
    }

    private fun loadSaved() {
        val s = prefs().getString("ids", "") ?: ""
        for (p in s.split(",")) {
            val id = p.trim().toIntOrNull() ?: continue
            if (awm.getAppWidgetInfo(id) != null) {
                ids.add(id)
                addWidgetView(id)
            }
        }
        save()
        updateEmpty()
    }

    private fun updateEmpty() {
        val tag = "empty"
        val old = box.findViewWithTag<View>(tag)
        if (old != null) box.removeView(old)
        if (ids.isEmpty()) {
            val t = TextView(this)
            t.tag = tag
            t.text = "Aucun widget.\nTouchez « ＋ Ajouter » pour choisir un widget d'une autre appli (météo, agenda, musique…)."
            t.setTextColor(Color.parseColor("#CCFFFFFF"))
            t.textSize = 16f
            t.gravity = Gravity.CENTER
            t.setPadding(dp(20), dp(80), dp(20), dp(20))
            box.addView(t)
        }
    }

    private fun addWidgetView(id: Int) {
        val info = awm.getAppWidgetInfo(id) ?: return
        val hv = host.createView(this, id, info)
        hv.setAppWidget(id, info)
        val wrap = FrameLayout(this)
        val h = maxOf(info.minHeight, dp(110))
        wrap.addView(hv, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, h))
        val x = TextView(this)
        x.text = "✕"
        x.setTextColor(Color.WHITE)
        x.textSize = 14f
        x.gravity = Gravity.CENTER
        x.setBackgroundColor(Color.parseColor("#99000000"))
        x.setOnClickListener { confirmRemove(id, wrap) }
        val lp = FrameLayout.LayoutParams(dp(30), dp(30), Gravity.TOP or Gravity.END)
        lp.setMargins(0, dp(6), dp(6), 0)
        wrap.addView(x, lp)
        val wl = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        wl.bottomMargin = dp(12)
        box.addView(wrap, wl)
    }

    private fun confirmRemove(id: Int, v: View) {
        AlertDialog.Builder(this)
            .setTitle("Retirer ce widget ?")
            .setPositiveButton("Retirer") { _, _ ->
                box.removeView(v)
                ids.remove(Integer.valueOf(id))
                try {
                    host.deleteAppWidgetId(id)
                } catch (e: Exception) {
                }
                save()
                updateEmpty()
            }
            .setNegativeButton("Annuler", null)
            .show()
    }

    private fun chooseProvider() {
        val pm = packageManager
        val list = awm.installedProviders
        val rows = ArrayList<Pair<String, AppWidgetProviderInfo>>()
        for (p in list) {
            val app = try {
                pm.getApplicationLabel(pm.getApplicationInfo(p.provider.packageName, 0)).toString()
            } catch (e: Exception) {
                p.provider.packageName
            }
            rows.add(Pair(app + " · " + p.loadLabel(pm), p))
        }
        rows.sortBy { it.first.lowercase() }
        val labels = Array(rows.size) { rows[it].first }
        AlertDialog.Builder(this)
            .setTitle("Choisir un widget")
            .setItems(labels) { _, i -> startAdd(rows[i].second) }
            .setNegativeButton("Annuler", null)
            .show()
    }

    private fun startAdd(info: AppWidgetProviderInfo) {
        val id = host.allocateAppWidgetId()
        pending = id
        if (awm.bindAppWidgetIdIfAllowed(id, info.provider)) {
            afterBind(id)
        } else {
            val i = Intent(AppWidgetManager.ACTION_APPWIDGET_BIND)
            i.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
            i.putExtra(AppWidgetManager.EXTRA_APPWIDGET_PROVIDER, info.provider)
            try {
                startActivityForResult(i, REQ_BIND)
            } catch (e: Exception) {
                host.deleteAppWidgetId(id)
            }
        }
    }

    private fun afterBind(id: Int) {
        val info = awm.getAppWidgetInfo(id)
        if (info != null && info.configure != null) {
            try {
                host.startAppWidgetConfigureActivityForResult(this, id, 0, REQ_CONF, null)
            } catch (e: Exception) {
                commit(id)
            }
        } else {
            commit(id)
        }
    }

    private fun commit(id: Int) {
        if (awm.getAppWidgetInfo(id) == null) return
        ids.add(id)
        save()
        updateEmpty()
        addWidgetView(id)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == REQ_BIND) {
            if (resultCode == RESULT_OK && pending >= 0) afterBind(pending) else if (pending >= 0) host.deleteAppWidgetId(pending)
            return
        }
        if (requestCode == REQ_CONF) {
            if (resultCode == RESULT_OK && pending >= 0) commit(pending) else if (pending >= 0) host.deleteAppWidgetId(pending)
            return
        }
        super.onActivityResult(requestCode, resultCode, data)
    }

    companion object {
        private const val HOST_ID = 4242
        private const val REQ_BIND = 31
        private const val REQ_CONF = 32
    }
}
