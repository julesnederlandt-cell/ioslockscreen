package com.lockscreen.ios27

import android.app.KeyguardManager
import android.app.Notification
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.Drawable
import android.os.Build
import android.os.Bundle
import android.service.notification.StatusBarNotification
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream

/**
 * Copie en mémoire, prête à envoyer à la page, des notifications du téléphone.
 * Elle est mise à jour par NotifService dès qu'une notification arrive, change ou disparaît,
 * donc la page n'a qu'à lire le texte JSON : rapide, et qui marche même si l'écran de
 * verrouillage n'était pas ouvert à ce moment-là.
 */
object NotifStore {
    @Volatile var json: String = "[]"
    @Volatile var count: Int = 0
    @Volatile var total: Int = 0
    @Volatile var updated: Long = 0
    @Volatile var error: String = ""

    private val labels = HashMap<String, String>()
    private val avatars = HashMap<String, String>()
    private val pictures = HashMap<String, String>()

    private fun label(ctx: Context, pkg: String): String {
        labels[pkg]?.let { return it }
        val l = try {
            ctx.packageManager.getApplicationLabel(ctx.packageManager.getApplicationInfo(pkg, 0)).toString()
        } catch (e: Exception) {
            pkg
        }
        labels[pkg] = l
        return l
    }

    fun refresh(ctx: Context, list: Array<StatusBarNotification>?, ranking: android.service.notification.NotificationListenerService.RankingMap?) {
        val l = list ?: emptyArray()
        total = l.size
        var errs = ""
        // groupes qui ont des notifications « enfants » : on ignore alors leur résumé
        val withKids = HashSet<String>()
        for (s in l) {
            try {
                val n = s.notification
                if ((n.flags and Notification.FLAG_GROUP_SUMMARY) == 0 && n.group != null) {
                    withKids.add(s.packageName + "|" + n.group)
                }
            } catch (e: Exception) {
            }
        }
        val km = ctx.getSystemService(Context.KEYGUARD_SERVICE) as? KeyguardManager
        val hidden = km != null && km.isKeyguardLocked && km.isKeyguardSecure
        val items = ArrayList<JSONObject>()
        for (s in l) {
            try {
                val o = convert(ctx, s, withKids, hidden, ranking)
                if (o != null) items.add(o)
            } catch (e: Exception) {
                errs = e.javaClass.simpleName + ": " + (e.message ?: "")
            }
        }
        items.sortByDescending { it.optLong("time") }
        val arr = JSONArray()
        var withImages = 0
        for (o in items) {
            // les images (avatar, grande photo) sont lourdes : seulement pour les plus récentes
            if (withImages >= 14) {
                o.remove("avatar")
                o.remove("pic")
            }
            withImages++
            arr.put(o)
        }
        json = arr.toString()
        count = items.size
        updated = System.currentTimeMillis()
        error = errs
        if (avatars.size > 80) avatars.clear()
        if (pictures.size > 30) pictures.clear()
    }

    @Suppress("DEPRECATION")
    private fun convert(
        ctx: Context,
        sbn: StatusBarNotification,
        withKids: Set<String>,
        hidden: Boolean,
        ranking: android.service.notification.NotificationListenerService.RankingMap?
    ): JSONObject? {
        val n = sbn.notification ?: return null
        if (sbn.packageName == ctx.packageName) return null
        val ex: Bundle = n.extras ?: Bundle()

        val summary = (n.flags and Notification.FLAG_GROUP_SUMMARY) != 0
        if (summary && withKids.contains(sbn.packageName + "|" + n.group)) return null

        // lecteurs de musique : le lecteur de l'écran de verrouillage les remplace
        val tpl = ex.getString(Notification.EXTRA_TEMPLATE) ?: ""
        if (n.category == Notification.CATEGORY_TRANSPORT || tpl.contains("MediaStyle") ||
            ex.containsKey(Notification.EXTRA_MEDIA_SESSION)
        ) return null

        // notifications permanentes (services en cours…), sauf appels et alarmes
        if (sbn.isOngoing && n.category != Notification.CATEGORY_CALL && n.category != Notification.CATEGORY_ALARM) return null

        // notifications silencieuses minimisées
        try {
            if (ranking != null) {
                val r = android.service.notification.NotificationListenerService.Ranking()
                if (ranking.getRanking(sbn.key, r) && r.importance <= 1) return null
            }
        } catch (e: Exception) {
        }

        var title = ex.getCharSequence(Notification.EXTRA_TITLE_BIG)?.toString() ?: ""
        if (title.isEmpty()) title = ex.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: ""
        if (title.isEmpty()) title = ex.getCharSequence(Notification.EXTRA_CONVERSATION_TITLE)?.toString() ?: ""

        val big = ex.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString() ?: ""
        val plain = ex.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: ""
        val sub = ex.getCharSequence(Notification.EXTRA_SUB_TEXT)?.toString() ?: ""
        val group = ex.getBoolean(Notification.EXTRA_IS_GROUP_CONVERSATION, false)
        val msgs = messages(ex, group)
        val inbox = ex.getCharSequenceArray(Notification.EXTRA_TEXT_LINES)?.map { it.toString() } ?: emptyList()

        var text = when {
            msgs.isNotEmpty() -> msgs.last()
            big.isNotEmpty() -> big
            plain.isNotEmpty() -> plain
            inbox.isNotEmpty() -> inbox.last()
            else -> sub
        }
        val lines: List<String> = when {
            msgs.size > 1 -> msgs.takeLast(5)
            inbox.size > 1 -> inbox.takeLast(5)
            else -> emptyList()
        }
        if (title.isEmpty() && text.isEmpty()) return null

        val app = label(ctx, sbn.packageName)
        if (hidden && n.visibility == Notification.VISIBILITY_SECRET) {
            title = app
            text = "Contenu masqué"
        }

        val post = sbn.postTime
        val w = n.`when`
        val time = if (w > 0 && w <= post + 60000 && w >= post - 43200000) w else post

        val o = JSONObject()
        o.put("key", sbn.key)
        o.put("pkg", sbn.packageName)
        o.put("app", app)
        o.put("title", title)
        o.put("text", text)
        o.put("time", time)
        o.put("cat", n.category ?: "")
        if (lines.isNotEmpty() && !(hidden && n.visibility == Notification.VISIBILITY_SECRET)) {
            o.put("lines", JSONArray(lines))
        }
        val max = ex.getInt(Notification.EXTRA_PROGRESS_MAX, 0)
        if (max > 0 && !ex.getBoolean(Notification.EXTRA_PROGRESS_INDETERMINATE, false)) {
            o.put("prog", (ex.getInt(Notification.EXTRA_PROGRESS, 0) * 100) / max)
        }
        if (!(hidden && n.visibility == Notification.VISIBILITY_SECRET)) {
            val ck = sbn.key + "|" + post
            try {
                var av = avatars[ck]
                if (av == null) {
                    val ic = n.getLargeIcon()
                    val d: Drawable? = ic?.loadDrawable(ctx)
                    if (d != null) {
                        av = b64(toBitmap(d, 96), true, 100)
                        avatars[ck] = av
                    }
                }
                if (av != null) o.put("avatar", av)
            } catch (e: Exception) {
            }
            try {
                var pic = pictures[ck]
                if (pic == null) {
                    val bmp = ex.getParcelable<Bitmap>(Notification.EXTRA_PICTURE)
                    if (bmp != null) {
                        pic = b64(scale(bmp, 480), false, 72)
                        pictures[ck] = pic
                    }
                }
                if (pic != null) o.put("pic", pic)
            } catch (e: Exception) {
            }
        }
        return o
    }

    @Suppress("DEPRECATION")
    private fun messages(ex: Bundle, group: Boolean): List<String> {
        val out = ArrayList<String>()
        try {
            val arr = ex.getParcelableArray(Notification.EXTRA_MESSAGES) ?: return out
            for (p in arr) {
                val b = p as? Bundle ?: continue
                val t = b.getCharSequence("text")?.toString() ?: continue
                var who: String? = null
                if (group) {
                    who = b.getCharSequence("sender")?.toString()
                    if (who == null && Build.VERSION.SDK_INT >= 28) {
                        try {
                            who = b.getParcelable<android.app.Person>("sender_person")?.name?.toString()
                        } catch (e: Exception) {
                        }
                    }
                }
                out.add(if (who.isNullOrEmpty()) t else "$who : $t")
            }
        } catch (e: Exception) {
        }
        return out
    }

    private fun scale(b: Bitmap, maxSide: Int): Bitmap {
        val m = maxSide.toFloat() / maxOf(b.width, b.height).toFloat()
        return if (m < 1f) Bitmap.createScaledBitmap(b, (b.width * m).toInt().coerceAtLeast(1), (b.height * m).toInt().coerceAtLeast(1), true) else b
    }

    private fun toBitmap(d: Drawable, size: Int): Bitmap {
        val w = if (d.intrinsicWidth > 0) d.intrinsicWidth else size
        val h = if (d.intrinsicHeight > 0) d.intrinsicHeight else size
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        d.setBounds(0, 0, w, h)
        d.draw(c)
        return scale(bmp, size)
    }

    private fun b64(b: Bitmap, png: Boolean, q: Int): String {
        val o = ByteArrayOutputStream()
        b.compress(if (png) Bitmap.CompressFormat.PNG else Bitmap.CompressFormat.JPEG, q, o)
        return "data:image/" + (if (png) "png" else "jpeg") + ";base64," + Base64.encodeToString(o.toByteArray(), Base64.NO_WRAP)
    }
}
