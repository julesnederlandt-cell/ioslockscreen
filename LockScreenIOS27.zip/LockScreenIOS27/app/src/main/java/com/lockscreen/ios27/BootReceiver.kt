package com.lockscreen.ios27

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Relance le service après un redémarrage du téléphone. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED && Prefs.persist(context)) {
            try {
                LockService.start(context)
            } catch (e: Exception) {
            }
        }
    }
}
